import React from 'react'

function DistrictMeeting() {
  return (
    <div>DistrictMeeting</div>
  )
}

export default DistrictMeeting