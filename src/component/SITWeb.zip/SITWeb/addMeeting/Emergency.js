import React from 'react'

function Emergency() {
  return (
    <div>Emergency</div>
  )
}

export default Emergency